# Draxeous
# � Draxeous by Dichill
# Visit us https://draxeousoffical.wixsite.com/officialrelease
# If your using this, take not this has a license!
# Draxeous Copyright Statement
# Draxeous API | Available for Dichill / Programmers

Please be noted that you need Python inorder to use this!

How to use :
Firstly, install pip you can find it on youtube
Secondly, do this on cmd once your done installing pip

- "pip install pyautogui"

once done you can now continue below.
----------------------------------------------------------
Edit Start.bat and change where your python.exe is located
You can change the settings in WORKMINES/WorkMinesSettings.py 
----------------------------------------------------------

Make sure you are in this page : https://workmines.com/user/earn/youtube.aspx
and do not close the messagebox and open start.bat