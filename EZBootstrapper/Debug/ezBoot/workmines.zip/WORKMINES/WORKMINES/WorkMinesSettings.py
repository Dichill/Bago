# Draxeous
# Draxeous by Dichill
# Visit us https://draxeousoffical.wixsite.com/officialrelease
# If your using this, take not this has a license!
# Draxeous Copyright Statement
# Draxeous API | Available for Dichill / Programmers

# Welcome to Settings
# Import your desired Settings
# This only works for 1920x1080
# Change the Coordinates by picturing it and measure the distance of the coordinates.
# Cmd
Cmd = "@: "

# Coordinates
class Coordinates:
    MessageBoxClose = (1273, 421)
    PlayAd = (493, 515)
    GoBack = (109, 584)

# Worker_Starting.py Seconds # Recommended Settings
MessageBoxClose_Seconds = (1)
PlayAd_Seconds = (1)
GoBack_Seconds = (80)

# Worker_Playback.py # Recommended Settings
MessageBoxClose_Seconds2 = (30)
PlayAd_Seconds2 = (3)
GoBack_Seconds2 = (80)
